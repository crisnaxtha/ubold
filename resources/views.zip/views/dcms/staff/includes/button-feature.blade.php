<div class="btn-group">
    <a href="{{ route($_base_route.'.get_feature_list') }}" class="btn btn-xs btn-success"><i class="fa fa-plus">&nbsp;Sort Feature {{ $_panel }}</i></a>
</div>
