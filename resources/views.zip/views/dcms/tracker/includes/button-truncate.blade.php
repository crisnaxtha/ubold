<div class="btn-group">
    <a href="{{ URL::route($_base_route.'.truncate') }}" class="btn btn-xs btn-danger"><i class="fa fa-trash">&nbsp;Delete All {{ $_panel }}</i></a>
</div>