<link href="{{ asset('assets/dcms/assets/fancybox/source/jquery.fancybox.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/dcms/css/gallery.css') }}" rel="stylesheet" />