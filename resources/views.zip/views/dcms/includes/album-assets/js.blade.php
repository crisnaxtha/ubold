<script type="text/javascript" language="javascript" src="{{ asset('assets/dcms/assets/fancybox/source/jquery.fancybox.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/dcms/js/modernizr.custom.js') }}"></script>
<script src="{{ asset('assets/dcms/js/toucheffects.js')  }}"></script>