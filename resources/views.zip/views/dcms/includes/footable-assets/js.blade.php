<script type="text/javascript" language="javascript" src="{{ asset('assets/dcms/assets/libs/footable/footable.all.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/dcms/assets/js/pages/foo-tables.init.js') }}"></script>
{{-- <script src="{{ asset('assets/dcms/js/dynamic_table_init.js')  }}"></script> --}}