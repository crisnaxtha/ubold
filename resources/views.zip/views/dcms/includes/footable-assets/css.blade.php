<link href="{{ asset('assets/dcms/assets/libs/footable/footable.core.min.css') }}" rel="stylesheet" />
{{-- <link href="{{ asset('assets/dcms/assets/advanced-datatable/media/css/demo_table.css') }}" rel="stylesheet" />
<link rel="stylesheet" href="{{ asset('assets/dcms/assets/data-tables/DT_bootstrap.css') }}" /> --}}