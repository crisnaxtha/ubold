
<div class="btn-group">
    <a href="{{ url()->previous() }}" class="btn btn-xs btn-info"><i class="fa fa-arrow-left">&nbsp;Back</i></a>
</div>
