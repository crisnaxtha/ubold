<a href="{{ route($_base_route.'.deleted_item')}} " class="btn btn-xs btn-danger"><i class="fa fa-trash-o"></i>&nbsp; {{ $_panel }} Recyle Bin </a>
