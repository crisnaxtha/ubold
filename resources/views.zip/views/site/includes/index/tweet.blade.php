<div class="twitter-feeds">
    {!! $all_view['setting']->social_feed !!}
</div>
<div class="clearfix"></div>
