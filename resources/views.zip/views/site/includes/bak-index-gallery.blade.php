<div class="gallery">
        <div class="container">
            <h4>{{ __('Gallery')}}</h4>
            <div class="row">
                <div class="col-md-4">
                    <div class="owl-carousel gallery-carousel">
                        <div class="item">
                            <div class="item-inner card">
                                <figure>
                                    <a href="#">
                                        <img src="images/service/service-5.jpg" class="img-fluid" alt="image">
                                        </a>
                                    </figure>
                                    <div class="card-body">
                                        <a href="#">
                                            <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                        </a>
                                        <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="item-inner card">
                                    <figure>
                                        <a href="#">
                                            <img src="images/service/service-6.jpg" class="img-fluid" alt="image">
                                            </a>
                                        </figure>
                                        <div class="card-body">
                                            <a href="#">
                                                <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                            </a>
                                            <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="item-inner card">
                                        <figure>
                                            <a href="#">
                                                <img src="images/service/service-4.jpg" class="img-fluid" alt="image">
                                                </a>
                                            </figure>
                                            <div class="card-body">
                                                <a href="#">
                                                    <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                                </a>
                                                <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="item-inner card">
                                            <figure>
                                                <a href="#">
                                                    <img src="images/service/service-3.jpg" class="img-fluid" alt="image">
                                                    </a>
                                                </figure>
                                                <div class="card-body">
                                                    <a href="#">
                                                        <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                                    </a>
                                                    <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <div class="owl-carousel gallery-carousel2">
                                        <div class="item">
                                            <div class="item-inner card">
                                                <figure>
                                                    <a href="#">
                                                        <img src="images/service/service-3.jpg" class="img-fluid" alt="image">
                                                        </a>
                                                    </figure>
                                                    <div class="card-body">
                                                        <a href="#">
                                                            <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                                        </a>
                                                        <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item">
                                                <div class="item-inner card">
                                                    <figure>
                                                        <a href="#">
                                                            <img src="images/service/service-5.jpg" class="img-fluid" alt="image">
                                                            </a>
                                                        </figure>
                                                        <div class="card-body">
                                                            <a href="#">
                                                                <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                                            </a>
                                                            <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item">
                                                    <div class="item-inner card">
                                                        <figure>
                                                            <a href="#">
                                                                <img src="images/service/service-6.jpg" class="img-fluid" alt="image">
                                                                </a>
                                                            </figure>
                                                            <div class="card-body">
                                                                <a href="#">
                                                                    <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                                                </a>
                                                                <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="item">
                                                        <div class="item-inner card">
                                                            <figure>
                                                                <a href="#">
                                                                    <img src="images/service/service-4.jpg" class="img-fluid" alt="image">
                                                                    </a>
                                                                </figure>
                                                                <div class="card-body">
                                                                    <a href="#">
                                                                        <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                                                    </a>
                                                                    <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="owl-carousel gallery-carousel3">
                                                        <div class="item">
                                                            <div class="item-inner card">
                                                                <figure>
                                                                    <a href="#">
                                                                        <img src="images/service/service-2.jpg" class="img-fluid" alt="image">
                                                                        </a>
                                                                    </figure>
                                                                    <div class="card-body">
                                                                        <a href="#">
                                                                            <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                                                        </a>
                                                                        <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="item-inner card">
                                                                    <figure>
                                                                        <a href="#">
                                                                            <img src="images/service/service-3.jpg" class="img-fluid" alt="image">
                                                                            </a>
                                                                        </figure>
                                                                        <div class="card-body">
                                                                            <a href="#">
                                                                                <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                                                            </a>
                                                                            <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="item">
                                                                    <div class="item-inner card">
                                                                        <figure>
                                                                            <a href="#">
                                                                                <img src="images/service/service-5.jpg" class="img-fluid" alt="image">
                                                                                </a>
                                                                            </figure>
                                                                            <div class="card-body">
                                                                                <a href="#">
                                                                                    <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                                                                </a>
                                                                                <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="item">
                                                                        <div class="item-inner card">
                                                                            <figure>
                                                                                <a href="#">
                                                                                    <img src="images/service/service-6.jpg" class="img-fluid" alt="image">
                                                                                    </a>
                                                                                </figure>
                                                                                <div class="card-body">
                                                                                    <a href="#">
                                                                                        <h6 class="card-title">फेरि चम्किन चाहेको एउटा पर्यटकीय गन्तव्य</h6>
                                                                                    </a>
                                                                                    <p>कुनै समय चितवनको प्रमुख पर्यटकीय गन्तब्य थियो, मेघौली । पर्यटककै चहलपहलले मेघौली विमानस्थल भरतपुर विमानस्थलभन्दा बढी व्यस्त हुन्थ्यो । ...</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="clearfix"></div>
